/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class Admin extends Person {

   
    public Admin(String phoneNumber, String Email, String firstName, String lastName, String passWord) {
        super(phoneNumber, Email, firstName, lastName, passWord);
    }
    
}
  

 
